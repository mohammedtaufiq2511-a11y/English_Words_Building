-- =====================================================================
-- SQL EXERCISES (sirf sawaal)  --  database: travel_db (travel_db_v2.sql)
-- Pehle khud likhne ki koshish karein, phir SQL_Solutions.sql se check karein.
-- =====================================================================

-- ---------------------------------------------------------------
-- WEEK 1: SQL Basics
-- ---------------------------------------------------------------
-- Q1.1  [Active agents with email]
-- Sabhi Active agents jinki email NULL nahi hai, naam ke alphabetical order mein, sirf pehle 20.


-- Q1.2  [Distinct values]
-- Agencies mein kaun-kaun se agency_type hain? (duplicates nahi chahiye)


-- Q1.3  [Unmatched premium hotels]
-- 4 ya 5 star hotels jinka giata_id NULL hai (unmatched hotels).


-- Q1.4  [BETWEEN + dates]
-- Confirmed bookings jinka amount 1000 se 2000 ke beech hai aur checkin 2026 mein hai.


-- Q1.5  [LIKE]
-- Wo agents jinka naam 'A' se start hota hai.


-- Q1.6  [INSERT / UPDATE / DELETE]
-- destinations mein ek nayi city 'Phuket' (id 13, Thailand, is_top10 FALSE) daalo, phir usse Top-10 bana do, phir delete kar do.



-- ---------------------------------------------------------------
-- WEEK 2: Aggregation aur Functions
-- ---------------------------------------------------------------
-- Q2.1  [GROUP BY basics]
-- Har booking status ke liye bookings ki sankhya aur total amount.


-- Q2.2  [Monthly revenue]
-- 2026 mein month-wise Confirmed revenue (month ke order mein).


-- Q2.3  [HAVING]
-- Wo agents jinki Confirmed bookings 100 se zyada hain. (WHERE vs HAVING ka fark samjho)


-- Q2.4  [CASE WHEN]
-- Bookings ko amount ke hisaab se bucket karo: Low (<1000), Medium (1000-3000), High (>3000) aur har bucket ki count nikalo.


-- Q2.5  [COALESCE + string functions]
-- Agents ki list: email NULL ho to 'no-email' dikhao, naam UPPER mein, aur email ka domain alag column mein.


-- Q2.6  [Date arithmetic]
-- Last-minute bookings: jahan checkin booking date ke 14 din ke andar ho. Kitni hain?



-- ---------------------------------------------------------------
-- WEEK 3: JOINs, Subqueries, CTEs
-- ---------------------------------------------------------------
-- Q3.1  [INNER JOIN chain]
-- Country-wise Confirmed bookings ki count aur revenue. (bookings -> agents -> branches -> agencies -> countries)


-- Q3.2  [LEFT JOIN]
-- Wo agents jinhone ek bhi booking nahi ki.


-- Q3.3  [SELF JOIN]
-- Har agent ke saath uske manager ka naam. (Jinka manager nahi hai wo bhi dikhne chahiye)


-- Q3.4  [Subquery]
-- Wo agents jinka total Confirmed revenue sabhi agents ke average revenue se zyada hai.


-- Q3.5  [CTE]
-- CTE use karke har destination city ka Confirmed revenue nikalo aur top 5 dikhao.


-- Q3.6  [INTERSECT]
-- Wo agents jinhone Dubai (id 1) aur Paris (id 3) dono ke liye bookings ki hain.


-- Q3.7  [CROSS JOIN]
-- Har country x har agency_type ka combination banao aur batao kitni agencies hain (0 bhi dikhna chahiye).



-- ---------------------------------------------------------------
-- WEEK 4: Advanced SQL (Window, Recursive)
-- ---------------------------------------------------------------
-- Q4.1  [ROW_NUMBER / RANK]
-- Har country ke top 3 agents (Confirmed revenue ke hisaab se).


-- Q4.2  [LAG]
-- Month-on-month Confirmed revenue growth % nikalo.


-- Q4.3  [Running total]
-- 2026 ka daily Confirmed revenue aur uska running (cumulative) total.


-- Q4.4  [Moving average]
-- Daily searches ki count aur uska 7-din ka moving average.


-- Q4.5  [NTILE]
-- Agents ko Confirmed revenue ke hisaab se 4 quartiles mein baanto (1 = best).


-- Q4.6  [Recursive CTE #1 (calendar)]
-- Recursive CTE se Jan 2026 ki saari dates banao aur batao kis din koi booking nahi hui.


-- Q4.7  [Recursive CTE #2 (hierarchy)]
-- Recursive CTE se org tree banao: har agent ka level (manager = level 1, uske reports = level 2) aur path. Sirf branch_id = 1 ke liye.


-- Q4.8  [Duplicates (stg_bookings_raw)]
-- stg_bookings_raw mein duplicate booking_ref dhoondho, phir duplicates delete karo (har ref ki sirf pehli row rakho).


-- Q4.9  [Pivot (FILTER)]
-- Month-wise ek row mein Confirmed, Cancelled aur Pending bookings ki count alag columns mein (pivot).



-- ---------------------------------------------------------------
-- WEEK 5: Database Design
-- ---------------------------------------------------------------
-- Q5.1  [CREATE TABLE with constraints]
-- agent_targets table banao: agent_id (FK), target_year, target_amount (> 0), created_at (default now). Primary key (agent_id, target_year).


-- Q5.2  [ALTER TABLE]
-- agents mein phone column add karo, aur bookings.nights par CHECK constraint lagao (nights > 0).


-- Q5.3  [Many-to-Many]
-- Har agent ke specialization destinations ek hi row mein comma-separated dikhao (STRING_AGG). Pehle 10 agents.


-- Q5.4  [Data cleaning -> clean table]
-- stg_bookings_raw ko clean karke bookings_clean table banao: agent_code UPPER+TRIM, status Initcap+TRIM, date proper DATE (2 formats), amount NUMERIC (comma hatao, blank = NULL), aur duplicates hata do.


-- Q5.5  [Foreign keys ki list (ER diagram ke liye)]
-- information_schema se saari foreign key relationships nikalo, phir dbdiagram.io par ER diagram banao.



-- ---------------------------------------------------------------
-- WEEK 6: Performance aur Reliability
-- ---------------------------------------------------------------
-- Q6.1  [Index: pehle aur baad]
-- Is query par EXPLAIN ANALYZE chalao (index se pehle), phir (agent_id, search_date) par index banao aur dobara chalao. Time compare karo.


-- Q6.2  [Sargable query]
-- bookings.booking_date par index banao. Phir 2026 ki bookings ko EXTRACT(YEAR ...) se aur date range se, dono tareeke se chalakar EXPLAIN mein fark dekho.


-- Q6.3  [Transaction]
-- Transaction ke andar booking 1 ko Cancelled karo, check karo, phir ROLLBACK karke wapas pehle jaisa kar do.


-- Q6.4  [View]
-- v_agent_revenue naam ka view banao: agent_id, agent_name, confirmed bookings aur revenue.


-- Q6.5  [Materialized view]
-- mv_monthly_revenue banao (month, revenue) aur use refresh karna seekho.


-- Q6.6  [Function]
-- get_agent_revenue(p_agent_id) function banao jo us agent ka Confirmed revenue return kare.


-- Q6.7  [Trigger]
-- bookings ka status badalne par audit_log mein entry daalne wala trigger banao. Test transaction ke andar karo.



-- ---------------------------------------------------------------
-- WEEK 7: Data Engineering Foundation
-- ---------------------------------------------------------------
-- Q7.1  [Star schema: dim aur fact]
-- dim_agent (agent + branch + agency + country ek jagah) aur fact_bookings table banao.


-- Q7.2  [Query on star schema]
-- Star schema se country aur agency_type ke hisaab se Confirmed revenue nikalo. (Ab sirf 2 table join hui, pehle 5 thi.)


-- Q7.3  [SCD Type 2]
-- dim_hotel_scd banao (valid_from, valid_to, is_current). Phir hotel 1 ki star rating badlo: purani row band karo, nayi row daalo.


-- Q7.4  [Incremental load]
-- Naye bookings (jo fact_bookings mein nahi hain) ko hi load karne ka pattern likho. (Staging -> fact)


-- Q7.5  [Partitioning]
-- searches ki partitioned copy banao (search_date ke hisaab se 2025 aur 2026 partitions). EXPLAIN mein partition pruning dekho.



-- ---------------------------------------------------------------
-- WEEK 8: Capstone Project
-- ---------------------------------------------------------------
-- Q8.1  [Search-to-booking conversion]
-- Destination-wise: total searches, total bookings, Confirmed bookings aur conversion % (confirmed/searches).


-- Q8.2  [Agent segmentation (aapka real kaam)]
-- Top-10 destinations par agents ko segment karo: searches_top10 aur confirmed_top10 ke hisaab se 'Power' (conv >= 20%), 'Browser' (searches >= 200 par conv < 10%), 'Dormant' (searches = 0) ya 'Regular'.


-- Q8.3  [Cancellation analysis]
-- agency_type aur country ke hisaab se cancellation rate (%) nikalo, sabse zyada cancellation wale upar.


-- Q8.4  [Trend + moving average]
-- Month-wise Confirmed revenue aur uska 3-month moving average.


-- Q8.5  [Data quality check]
-- Confirmed bookings jinke payments ka total booking amount se match nahi karta (0 aana chahiye), aur payment ke bina Confirmed bookings.


