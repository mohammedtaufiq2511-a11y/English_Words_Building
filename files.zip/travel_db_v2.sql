-- =====================================================================
-- TRAVEL DATABASE V2  (PostgreSQL)  --  2 Months SQL Practice
-- =====================================================================
-- Kaise chalayein:
--   1) CREATE DATABASE travel_db;   (phir us database se connect karein)
--   2) Ye poori script ek baar run karein (DBeaver: Alt + X). ~10-30 sec lagenge.
--   3) Data script khud generate karti hai, isliye file chhoti hai.
--
-- Tables (12):
--   Core (10): countries, agencies, branches, agents, destinations, hotels,
--              agent_destination_map, searches, bookings, payments
--   Practice (2): audit_log (khali, Triggers ke liye), stg_bookings_raw (dirty data)
--
-- Hierarchy:  countries -> agencies -> branches -> agents
-- Flow:       agents -> searches -> bookings -> payments   (hotels, destinations alag)
--
-- NOTE: Jaan-bujhkar PRIMARY KEY ke alawa koi extra INDEX nahi banaya gaya.
--       Week 6 mein khud index banakar EXPLAIN ANALYZE se fark dekhein.
-- =====================================================================

SELECT setseed(0.42);   -- har baar same data generate hoga

DROP TABLE IF EXISTS stg_bookings_raw, audit_log, payments, bookings, searches,
                     agent_destination_map, hotels, destinations, agents,
                     branches, agencies, countries CASCADE;

-- ---------------------------------------------------------------------
-- 1. SCHEMA
-- ---------------------------------------------------------------------
CREATE TABLE countries (
  country_id    INT PRIMARY KEY,
  country_name  VARCHAR(50) NOT NULL UNIQUE,
  region        VARCHAR(30),
  currency      CHAR(3)
);

CREATE TABLE agencies (
  agency_id     INT PRIMARY KEY,
  agency_name   VARCHAR(100) NOT NULL,
  country_id    INT NOT NULL REFERENCES countries(country_id),
  agency_type   VARCHAR(20) NOT NULL,            -- Online / Offline / Corporate
  joined_date   DATE
);

CREATE TABLE branches (
  branch_id     INT PRIMARY KEY,
  agency_id     INT NOT NULL REFERENCES agencies(agency_id),
  branch_name   VARCHAR(100) NOT NULL,
  city          VARCHAR(50)
);

CREATE TABLE agents (
  agent_id      INT PRIMARY KEY,
  agent_code    VARCHAR(10) NOT NULL UNIQUE,
  agent_name    VARCHAR(100) NOT NULL,
  branch_id     INT NOT NULL REFERENCES branches(branch_id),
  manager_id    INT REFERENCES agents(agent_id),  -- NULL = branch manager
  status        VARCHAR(10) NOT NULL DEFAULT 'Active',
  email         VARCHAR(100),                     -- kuch NULL hain
  joined_date   DATE
);

CREATE TABLE destinations (
  destination_id INT PRIMARY KEY,
  city           VARCHAR(50) NOT NULL,
  country_name   VARCHAR(50) NOT NULL,
  is_top10       BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE hotels (
  hotel_id       INT PRIMARY KEY,
  hotel_name     VARCHAR(100) NOT NULL,
  destination_id INT NOT NULL REFERENCES destinations(destination_id),
  star_rating    INT CHECK (star_rating BETWEEN 1 AND 5),
  giata_id       INT                              -- NULL = unmatched hotel
);

-- Many-to-Many: ek agent kai destinations mein specialist, ek destination ke kai agents
CREATE TABLE agent_destination_map (
  agent_id       INT NOT NULL REFERENCES agents(agent_id),
  destination_id INT NOT NULL REFERENCES destinations(destination_id),
  PRIMARY KEY (agent_id, destination_id)
);

CREATE TABLE searches (
  search_id      BIGINT PRIMARY KEY,
  agent_id       INT NOT NULL REFERENCES agents(agent_id),
  destination_id INT NOT NULL REFERENCES destinations(destination_id),
  search_ts      TIMESTAMP NOT NULL,
  search_date    DATE NOT NULL,
  checkin_date   DATE NOT NULL,
  nights         INT NOT NULL,
  adults         INT NOT NULL
);

CREATE TABLE bookings (
  booking_id     BIGINT PRIMARY KEY,
  search_id      BIGINT NOT NULL REFERENCES searches(search_id),
  agent_id       INT NOT NULL REFERENCES agents(agent_id),
  hotel_id       INT NOT NULL REFERENCES hotels(hotel_id),
  booking_date   DATE NOT NULL,
  checkin_date   DATE NOT NULL,
  nights         INT NOT NULL,
  amount         NUMERIC(10,2) NOT NULL,
  status         VARCHAR(15) NOT NULL             -- Confirmed / Cancelled / Pending
);

CREATE TABLE payments (
  payment_id     BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  booking_id     BIGINT NOT NULL REFERENCES bookings(booking_id),
  payment_date   DATE NOT NULL,
  amount         NUMERIC(10,2) NOT NULL,
  method         VARCHAR(20) NOT NULL,
  status         VARCHAR(10) NOT NULL
);

-- Khali table: Week 6 mein isi par TRIGGER banana hai
CREATE TABLE audit_log (
  log_id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  table_name     VARCHAR(50),
  record_id      BIGINT,
  action         VARCHAR(10),
  old_value      TEXT,
  new_value      TEXT,
  changed_at     TIMESTAMP DEFAULT NOW()
);

-- Dirty staging table: sab kuch TEXT, koi constraint nahi (ETL / cleaning practice)
CREATE TABLE stg_bookings_raw (
  raw_id         INT GENERATED ALWAYS AS IDENTITY,
  booking_ref    TEXT,
  agent_code     TEXT,
  hotel_name     TEXT,
  booking_date   TEXT,
  amount         TEXT,
  status         TEXT,
  loaded_at      TIMESTAMP DEFAULT NOW()
);

-- ---------------------------------------------------------------------
-- 2. DATA GENERATION
-- ---------------------------------------------------------------------

-- countries (8)
INSERT INTO countries VALUES
 (1,'India','Asia','INR'),(2,'UAE','Middle East','AED'),(3,'UK','Europe','GBP'),
 (4,'Germany','Europe','EUR'),(5,'USA','North America','USD'),
 (6,'Singapore','Asia','SGD'),(7,'Australia','Oceania','AUD'),(8,'France','Europe','EUR');

-- agencies (60)
INSERT INTO agencies
SELECT g,
       (ARRAY['Sky','Blue','Globe','Royal','Sunrise','Golden','Wanderlust','Nomad','Horizon','Pearl'])[1 + g % 10]
         || ' Travels ' || g,
       1 + (g - 1) % 8,
       (ARRAY['Online','Offline','Corporate'])[1 + g % 3],
       DATE '2015-01-01' + (random() * 3000)::int
FROM generate_series(1, 60) g;

-- branches (1 to 4 per agency)
INSERT INTO branches
SELECT row_number() OVER (ORDER BY a.agency_id, b),
       a.agency_id,
       a.agency_name || ' - Branch ' || b,
       (ARRAY['Mumbai','Delhi','Dubai','London','Berlin','New York','Singapore','Sydney','Paris','Ahmedabad'])
         [1 + (random() * 9)::int]
FROM agencies a
CROSS JOIN LATERAL generate_series(1, 1 + a.agency_id % 4) b;

-- agents (5 to 12 per branch). Agent 1 of each branch = manager.
-- (OFFSET 0 = PostgreSQL ko random() har row ke liye alag evaluate karne par majboor karta hai)
INSERT INTO agents (agent_id, agent_code, agent_name, branch_id, status, email, joined_date)
SELECT x.agent_id,
       'AG' || (1000 + x.agent_id),
       x.fn || ' ' || x.ln,
       x.branch_id,
       'Active',
       CASE WHEN x.r < 0.10 THEN NULL
            ELSE lower(x.fn || '.' || x.ln) || x.agent_id || '@mail.com' END,
       x.jd
FROM (
  SELECT row_number() OVER (ORDER BY br.branch_id, n) AS agent_id,
         br.branch_id,
         (ARRAY['Amit','Priya','John','Sara','Rahul','Emma','Omar','Lena','Vikram','Anna',
                'Raj','Mia','Karan','Zoe','Dev','Nina','Arjun','Hana','Tom','Isha'])[1 + (random()*19)::int] AS fn,
         (ARRAY['Shah','Patel','Smith','Khan','Mehta','Brown','Ali','Muller','Singh','Rossi',
                'Joshi','Kapoor','Lee','Davis','Nair'])[1 + (random()*14)::int] AS ln,
         random() AS r,
         DATE '2018-01-01' + (random() * 2550)::int AS jd          -- sab 2024 se pehle join hue
  FROM branches br
  CROSS JOIN LATERAL generate_series(1, 5 + (br.branch_id % 8)) n
  OFFSET 0
) x;

-- manager_id: branch ka pehla agent manager, baaki uske neeche
UPDATE agents a
SET manager_id = m.first_agent
FROM (SELECT branch_id, MIN(agent_id) AS first_agent FROM agents GROUP BY branch_id) m
WHERE a.branch_id = m.branch_id AND a.agent_id <> m.first_agent;

-- last 10% agents Inactive (inhone koi search/booking nahi ki)
UPDATE agents SET status = 'Inactive'
WHERE agent_id > (SELECT FLOOR(MAX(agent_id) * 0.90) FROM agents);

-- destinations (12): pehle 10 Top-10
INSERT INTO destinations VALUES
 (1,'Dubai','UAE',TRUE),(2,'London','UK',TRUE),(3,'Paris','France',TRUE),
 (4,'Bangkok','Thailand',TRUE),(5,'Singapore','Singapore',TRUE),(6,'New York','USA',TRUE),
 (7,'Istanbul','Turkey',TRUE),(8,'Bali','Indonesia',TRUE),(9,'Rome','Italy',TRUE),
 (10,'Maldives','Maldives',TRUE),(11,'Goa','India',FALSE),(12,'Berlin','Germany',FALSE);

-- hotels (240 = har destination mein 20). hotel_id = destination + 12*k
INSERT INTO hotels
SELECT g,
       d.city || ' ' || (ARRAY['Grand','Palace','Plaza','Resort','Suites','Inn','Residency','Boutique'])[1 + g % 8] || ' ' || g,
       d.destination_id,
       2 + (random() * 3)::int,
       CASE WHEN random() < 0.20 THEN NULL ELSE 50000 + g * 7 END
FROM generate_series(1, 240) g
JOIN destinations d ON d.destination_id = 1 + (g - 1) % 12;

-- agent_destination_map: har agent 1-4 destinations (duplicates ON CONFLICT se hat jaate hain)
INSERT INTO agent_destination_map
SELECT a.agent_id, 1 + (random() * 11)::int
FROM agents a
CROSS JOIN LATERAL generate_series(1, 1 + (a.agent_id * 7) % 4) s
ON CONFLICT DO NOTHING;

-- searches (200,000): 2025-01-01 se 2026-09-30 tak daily data. Recent dinon mein zyada.
INSERT INTO searches
SELECT x.g,
       1 + FLOOR((SELECT FLOOR(MAX(agent_id) * 0.90) FROM agents) * x.ra * x.ra)::int,   -- kuch agents bahut active
       1 + FLOOR(12 * power(x.rd, 1.5))::int,                                          -- Top-10 zyada search hote hain
       x.dt + (x.rt * 86399)::int * INTERVAL '1 second',
       x.dt,
       x.dt + 7 + (x.rc * 90)::int,
       1 + (x.rn * 9)::int,
       1 + (x.rp * 3)::int
FROM (
  SELECT g,
         random() AS ra, random() AS rd, random() AS rt, random() AS rc, random() AS rn, random() AS rp,
         DATE '2025-01-01' + FLOOR(638 * sqrt(random()))::int AS dt
  FROM generate_series(1, 200000) g
  OFFSET 0
) x;

-- bookings (~30% searches book hoti hain). Hotel same destination ka.
-- (MATERIALIZED = random values ek hi baar fix hote hain)
WITH s AS MATERIALIZED (
  SELECT se.*, random() AS r,
         se.destination_id + 12 * (random() * 19)::int AS hotel_id
  FROM searches se
  WHERE random() < 0.30
)
INSERT INTO bookings
SELECT row_number() OVER (ORDER BY s.search_id),
       s.search_id,
       s.agent_id,
       s.hotel_id,
       LEAST(s.search_date + (random() * 2)::int, DATE '2026-10-06'),
       s.checkin_date,
       s.nights,
       ROUND((s.nights * (60 + random() * 60) * h.star_rating * (0.8 + random() * 0.5))::numeric, 2),
       (ARRAY['Confirmed','Cancelled','Pending'])[CASE WHEN s.r < 0.72 THEN 1 WHEN s.r < 0.92 THEN 2 ELSE 3 END]
FROM s
JOIN hotels h ON h.hotel_id = s.hotel_id;

-- payments: Confirmed bookings ke liye (60% single payment, 40% deposit 30% + balance 70%)
-- (booking_id % 5 < 2 wale 40% bookings split hote hain; deterministic rakha taaki totals hamesha match karein)
INSERT INTO payments (booking_id, payment_date, amount, method, status)
SELECT b.booking_id,
       b.booking_date + p.off,
       ROUND(b.amount * p.share, 2),
       (ARRAY['Credit Card','Bank Transfer','UPI','Wallet'])[1 + (random() * 3)::int],
       'Paid'
FROM bookings b
CROSS JOIN LATERAL (VALUES (0, 0.3, 1), (7, 0.7, 2), (0, 1.0, 3)) AS p(off, share, kind)
WHERE b.status = 'Confirmed'
  AND ((b.booking_id % 5 < 2 AND p.kind IN (1, 2)) OR (b.booking_id % 5 >= 2 AND p.kind = 3));

-- stg_bookings_raw: dirty data (extra spaces, mixed case, 2 date formats, comma amounts, NULL/blank, duplicates)
INSERT INTO stg_bookings_raw (booking_ref, agent_code, hotel_name, booking_date, amount, status)
SELECT 'BK' || b.booking_id,
       CASE (random() * 3)::int
            WHEN 0 THEN lower(a.agent_code)
            WHEN 1 THEN ' ' || a.agent_code || ' '
            ELSE a.agent_code END,
       h.hotel_name,
       CASE WHEN random() < 0.5 THEN to_char(b.booking_date, 'YYYY-MM-DD')
            ELSE to_char(b.booking_date, 'DD/MM/YYYY') END,
       CASE WHEN random() < 0.05 THEN NULL
            WHEN random() < 0.10 THEN ''
            WHEN random() < 0.40 THEN to_char(b.amount, 'FM999,999.00')
            ELSE b.amount::text END,
       CASE (random() * 4)::int
            WHEN 0 THEN lower(b.status)
            WHEN 1 THEN upper(b.status)
            WHEN 2 THEN b.status || ' '
            ELSE b.status END
FROM bookings b
JOIN agents a ON a.agent_id = b.agent_id
JOIN hotels h ON h.hotel_id = b.hotel_id
WHERE b.booking_id <= 3000;

-- ~150 exact duplicate rows
INSERT INTO stg_bookings_raw (booking_ref, agent_code, hotel_name, booking_date, amount, status)
SELECT booking_ref, agent_code, hotel_name, booking_date, amount, status
FROM stg_bookings_raw
WHERE raw_id % 20 = 0;

ANALYZE;

-- ---------------------------------------------------------------------
-- 3. CHECK: row counts
-- ---------------------------------------------------------------------
SELECT 'countries' AS table_name, COUNT(*) AS row_count FROM countries
UNION ALL SELECT 'agencies', COUNT(*) FROM agencies
UNION ALL SELECT 'branches', COUNT(*) FROM branches
UNION ALL SELECT 'agents', COUNT(*) FROM agents
UNION ALL SELECT 'destinations', COUNT(*) FROM destinations
UNION ALL SELECT 'hotels', COUNT(*) FROM hotels
UNION ALL SELECT 'agent_destination_map', COUNT(*) FROM agent_destination_map
UNION ALL SELECT 'searches', COUNT(*) FROM searches
UNION ALL SELECT 'bookings', COUNT(*) FROM bookings
UNION ALL SELECT 'payments', COUNT(*) FROM payments
UNION ALL SELECT 'audit_log', COUNT(*) FROM audit_log
UNION ALL SELECT 'stg_bookings_raw', COUNT(*) FROM stg_bookings_raw;
