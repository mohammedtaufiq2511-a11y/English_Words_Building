-- =====================================================================
-- SQL SOLUTIONS  --  database: travel_db (travel_db_v2.sql)
-- Pehle khud try karein! Ek solution ek se zyada tareeke se bhi ho sakta hai.
-- Kuch solutions table/index/view banate hain. Week order mein chalayein.
-- =====================================================================

-- ---------------------------------------------------------------
-- WEEK 1: SQL Basics
-- ---------------------------------------------------------------
-- Q1.1  [Active agents with email]
-- Sabhi Active agents jinki email NULL nahi hai, naam ke alphabetical order mein, sirf pehle 20.
SELECT agent_id, agent_code, agent_name, email
FROM agents
WHERE status = 'Active' AND email IS NOT NULL
ORDER BY agent_name
LIMIT 20;

-- Q1.2  [Distinct values]
-- Agencies mein kaun-kaun se agency_type hain? (duplicates nahi chahiye)
SELECT DISTINCT agency_type FROM agencies;

-- Q1.3  [Unmatched premium hotels]
-- 4 ya 5 star hotels jinka giata_id NULL hai (unmatched hotels).
SELECT hotel_id, hotel_name, star_rating
FROM hotels
WHERE star_rating IN (4, 5) AND giata_id IS NULL;

-- Q1.4  [BETWEEN + dates]
-- Confirmed bookings jinka amount 1000 se 2000 ke beech hai aur checkin 2026 mein hai.
SELECT booking_id, amount, checkin_date
FROM bookings
WHERE status = 'Confirmed'
  AND amount BETWEEN 1000 AND 2000
  AND checkin_date >= DATE '2026-01-01' AND checkin_date < DATE '2027-01-01';

-- Q1.5  [LIKE]
-- Wo agents jinka naam 'A' se start hota hai.
SELECT agent_id, agent_name FROM agents WHERE agent_name LIKE 'A%';

-- Q1.6  [INSERT / UPDATE / DELETE]
-- destinations mein ek nayi city 'Phuket' (id 13, Thailand, is_top10 FALSE) daalo, phir usse Top-10 bana do, phir delete kar do.
INSERT INTO destinations (destination_id, city, country_name, is_top10)
VALUES (13, 'Phuket', 'Thailand', FALSE);

UPDATE destinations SET is_top10 = TRUE WHERE destination_id = 13;

DELETE FROM destinations WHERE destination_id = 13;


-- ---------------------------------------------------------------
-- WEEK 2: Aggregation aur Functions
-- ---------------------------------------------------------------
-- Q2.1  [GROUP BY basics]
-- Har booking status ke liye bookings ki sankhya aur total amount.
SELECT status, COUNT(*) AS total_bookings, SUM(amount) AS total_amount
FROM bookings
GROUP BY status;

-- Q2.2  [Monthly revenue]
-- 2026 mein month-wise Confirmed revenue (month ke order mein).
SELECT DATE_TRUNC('month', booking_date)::date AS month, SUM(amount) AS revenue
FROM bookings
WHERE status = 'Confirmed' AND booking_date >= DATE '2026-01-01'
GROUP BY 1
ORDER BY 1;

-- Q2.3  [HAVING]
-- Wo agents jinki Confirmed bookings 100 se zyada hain. (WHERE vs HAVING ka fark samjho)
SELECT agent_id, COUNT(*) AS confirmed_bookings
FROM bookings
WHERE status = 'Confirmed'
GROUP BY agent_id
HAVING COUNT(*) > 100
ORDER BY confirmed_bookings DESC;

-- Q2.4  [CASE WHEN]
-- Bookings ko amount ke hisaab se bucket karo: Low (<1000), Medium (1000-3000), High (>3000) aur har bucket ki count nikalo.
SELECT CASE WHEN amount < 1000 THEN 'Low'
            WHEN amount <= 3000 THEN 'Medium'
            ELSE 'High' END AS bucket,
       COUNT(*) AS bookings
FROM bookings
GROUP BY 1
ORDER BY 2 DESC;

-- Q2.5  [COALESCE + string functions]
-- Agents ki list: email NULL ho to 'no-email' dikhao, naam UPPER mein, aur email ka domain alag column mein.
SELECT agent_id,
       UPPER(agent_name) AS name_upper,
       COALESCE(email, 'no-email') AS email,
       SPLIT_PART(email, '@', 2) AS domain
FROM agents
LIMIT 20;

-- Q2.6  [Date arithmetic]
-- Last-minute bookings: jahan checkin booking date ke 14 din ke andar ho. Kitni hain?
SELECT COUNT(*) AS last_minute_bookings
FROM bookings
WHERE checkin_date - booking_date <= 14;


-- ---------------------------------------------------------------
-- WEEK 3: JOINs, Subqueries, CTEs
-- ---------------------------------------------------------------
-- Q3.1  [INNER JOIN chain]
-- Country-wise Confirmed bookings ki count aur revenue. (bookings -> agents -> branches -> agencies -> countries)
SELECT c.country_name, COUNT(*) AS bookings, SUM(b.amount) AS revenue
FROM bookings b
JOIN agents a    ON a.agent_id = b.agent_id
JOIN branches br ON br.branch_id = a.branch_id
JOIN agencies ag ON ag.agency_id = br.agency_id
JOIN countries c ON c.country_id = ag.country_id
WHERE b.status = 'Confirmed'
GROUP BY c.country_name
ORDER BY revenue DESC;

-- Q3.2  [LEFT JOIN]
-- Wo agents jinhone ek bhi booking nahi ki.
SELECT a.agent_id, a.agent_code, a.status
FROM agents a
LEFT JOIN bookings b ON b.agent_id = a.agent_id
WHERE b.booking_id IS NULL;

-- Q3.3  [SELF JOIN]
-- Har agent ke saath uske manager ka naam. (Jinka manager nahi hai wo bhi dikhne chahiye)
SELECT a.agent_id, a.agent_name, m.agent_name AS manager_name
FROM agents a
LEFT JOIN agents m ON m.agent_id = a.manager_id
ORDER BY a.agent_id
LIMIT 30;

-- Q3.4  [Subquery]
-- Wo agents jinka total Confirmed revenue sabhi agents ke average revenue se zyada hai.
SELECT agent_id, SUM(amount) AS revenue
FROM bookings
WHERE status = 'Confirmed'
GROUP BY agent_id
HAVING SUM(amount) > (
    SELECT AVG(agent_rev) FROM (
        SELECT SUM(amount) AS agent_rev
        FROM bookings WHERE status = 'Confirmed'
        GROUP BY agent_id) t
)
ORDER BY revenue DESC;

-- Q3.5  [CTE]
-- CTE use karke har destination city ka Confirmed revenue nikalo aur top 5 dikhao.
WITH city_revenue AS (
    SELECT d.city, SUM(b.amount) AS revenue
    FROM bookings b
    JOIN hotels h        ON h.hotel_id = b.hotel_id
    JOIN destinations d  ON d.destination_id = h.destination_id
    WHERE b.status = 'Confirmed'
    GROUP BY d.city
)
SELECT city, revenue
FROM city_revenue
ORDER BY revenue DESC
LIMIT 5;

-- Q3.6  [INTERSECT]
-- Wo agents jinhone Dubai (id 1) aur Paris (id 3) dono ke liye bookings ki hain.
SELECT b.agent_id FROM bookings b JOIN hotels h ON h.hotel_id = b.hotel_id WHERE h.destination_id = 1
INTERSECT
SELECT b.agent_id FROM bookings b JOIN hotels h ON h.hotel_id = b.hotel_id WHERE h.destination_id = 3;

-- Q3.7  [CROSS JOIN]
-- Har country x har agency_type ka combination banao aur batao kitni agencies hain (0 bhi dikhna chahiye).
SELECT c.country_name, t.agency_type, COUNT(ag.agency_id) AS agencies
FROM countries c
CROSS JOIN (SELECT DISTINCT agency_type FROM agencies) t
LEFT JOIN agencies ag ON ag.country_id = c.country_id AND ag.agency_type = t.agency_type
GROUP BY c.country_name, t.agency_type
ORDER BY c.country_name, t.agency_type;


-- ---------------------------------------------------------------
-- WEEK 4: Advanced SQL (Window, Recursive)
-- ---------------------------------------------------------------
-- Q4.1  [ROW_NUMBER / RANK]
-- Har country ke top 3 agents (Confirmed revenue ke hisaab se).
WITH agent_rev AS (
    SELECT c.country_name, a.agent_id, SUM(b.amount) AS revenue
    FROM bookings b
    JOIN agents a    ON a.agent_id = b.agent_id
    JOIN branches br ON br.branch_id = a.branch_id
    JOIN agencies ag ON ag.agency_id = br.agency_id
    JOIN countries c ON c.country_id = ag.country_id
    WHERE b.status = 'Confirmed'
    GROUP BY c.country_name, a.agent_id
), ranked AS (
    SELECT *, RANK() OVER (PARTITION BY country_name ORDER BY revenue DESC) AS rnk
    FROM agent_rev
)
SELECT * FROM ranked WHERE rnk <= 3 ORDER BY country_name, rnk;

-- Q4.2  [LAG]
-- Month-on-month Confirmed revenue growth % nikalo.
WITH m AS (
    SELECT DATE_TRUNC('month', booking_date)::date AS month, SUM(amount) AS revenue
    FROM bookings WHERE status = 'Confirmed'
    GROUP BY 1
)
SELECT month, revenue,
       LAG(revenue) OVER (ORDER BY month) AS prev_revenue,
       ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month))
             / NULLIF(LAG(revenue) OVER (ORDER BY month), 0), 1) AS growth_pct
FROM m
ORDER BY month;

-- Q4.3  [Running total]
-- 2026 ka daily Confirmed revenue aur uska running (cumulative) total.
WITH d AS (
    SELECT booking_date, SUM(amount) AS revenue
    FROM bookings
    WHERE status = 'Confirmed' AND booking_date >= DATE '2026-01-01'
    GROUP BY booking_date
)
SELECT booking_date, revenue,
       SUM(revenue) OVER (ORDER BY booking_date) AS running_total
FROM d
ORDER BY booking_date;

-- Q4.4  [Moving average]
-- Daily searches ki count aur uska 7-din ka moving average.
WITH d AS (
    SELECT search_date, COUNT(*) AS searches FROM searches GROUP BY search_date
)
SELECT search_date, searches,
       ROUND(AVG(searches) OVER (ORDER BY search_date
             ROWS BETWEEN 6 PRECEDING AND CURRENT ROW), 1) AS moving_avg_7d
FROM d
ORDER BY search_date;

-- Q4.5  [NTILE]
-- Agents ko Confirmed revenue ke hisaab se 4 quartiles mein baanto (1 = best).
SELECT agent_id, revenue, NTILE(4) OVER (ORDER BY revenue DESC) AS quartile
FROM (SELECT agent_id, SUM(amount) AS revenue
      FROM bookings WHERE status = 'Confirmed' GROUP BY agent_id) t
ORDER BY revenue DESC;

-- Q4.6  [Recursive CTE #1 (calendar)]
-- Recursive CTE se Jan 2026 ki saari dates banao aur batao kis din koi booking nahi hui.
WITH RECURSIVE days AS (
    SELECT DATE '2026-01-01' AS d
    UNION ALL
    SELECT d + 1 FROM days WHERE d < DATE '2026-01-31'
)
SELECT days.d
FROM days
LEFT JOIN bookings b ON b.booking_date = days.d
WHERE b.booking_id IS NULL;

-- Q4.7  [Recursive CTE #2 (hierarchy)]
-- Recursive CTE se org tree banao: har agent ka level (manager = level 1, uske reports = level 2) aur path. Sirf branch_id = 1 ke liye.
WITH RECURSIVE org AS (
    SELECT agent_id, agent_name, manager_id, 1 AS level, agent_name::text AS path
    FROM agents
    WHERE manager_id IS NULL AND branch_id = 1
    UNION ALL
    SELECT a.agent_id, a.agent_name, a.manager_id, o.level + 1, o.path || ' > ' || a.agent_name
    FROM agents a
    JOIN org o ON a.manager_id = o.agent_id
)
SELECT * FROM org ORDER BY level, agent_id;

-- Q4.8  [Duplicates (stg_bookings_raw)]
-- stg_bookings_raw mein duplicate booking_ref dhoondho, phir duplicates delete karo (har ref ki sirf pehli row rakho).
-- Duplicates dekhna
SELECT booking_ref, COUNT(*) FROM stg_bookings_raw GROUP BY booking_ref HAVING COUNT(*) > 1;

-- Duplicates delete karna
DELETE FROM stg_bookings_raw
WHERE raw_id IN (
    SELECT raw_id FROM (
        SELECT raw_id, ROW_NUMBER() OVER (PARTITION BY booking_ref ORDER BY raw_id) AS rn
        FROM stg_bookings_raw) t
    WHERE rn > 1
);

-- Q4.9  [Pivot (FILTER)]
-- Month-wise ek row mein Confirmed, Cancelled aur Pending bookings ki count alag columns mein (pivot).
SELECT DATE_TRUNC('month', booking_date)::date AS month,
       COUNT(*) FILTER (WHERE status = 'Confirmed') AS confirmed,
       COUNT(*) FILTER (WHERE status = 'Cancelled') AS cancelled,
       COUNT(*) FILTER (WHERE status = 'Pending')   AS pending
FROM bookings
GROUP BY 1
ORDER BY 1;


-- ---------------------------------------------------------------
-- WEEK 5: Database Design
-- ---------------------------------------------------------------
-- Q5.1  [CREATE TABLE with constraints]
-- agent_targets table banao: agent_id (FK), target_year, target_amount (> 0), created_at (default now). Primary key (agent_id, target_year).
CREATE TABLE agent_targets (
    agent_id      INT NOT NULL REFERENCES agents(agent_id),
    target_year   INT NOT NULL,
    target_amount NUMERIC(12,2) NOT NULL CHECK (target_amount > 0),
    created_at    TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY (agent_id, target_year)
);

INSERT INTO agent_targets (agent_id, target_year, target_amount) VALUES (1, 2026, 500000);

-- Q5.2  [ALTER TABLE]
-- agents mein phone column add karo, aur bookings.nights par CHECK constraint lagao (nights > 0).
ALTER TABLE agents ADD COLUMN phone VARCHAR(20);
ALTER TABLE bookings ADD CONSTRAINT chk_nights_positive CHECK (nights > 0);

-- Q5.3  [Many-to-Many]
-- Har agent ke specialization destinations ek hi row mein comma-separated dikhao (STRING_AGG). Pehle 10 agents.
SELECT a.agent_id, a.agent_name, STRING_AGG(d.city, ', ' ORDER BY d.city) AS specializations
FROM agents a
JOIN agent_destination_map m ON m.agent_id = a.agent_id
JOIN destinations d          ON d.destination_id = m.destination_id
GROUP BY a.agent_id, a.agent_name
ORDER BY a.agent_id
LIMIT 10;

-- Q5.4  [Data cleaning -> clean table]
-- stg_bookings_raw ko clean karke bookings_clean table banao: agent_code UPPER+TRIM, status Initcap+TRIM, date proper DATE (2 formats), amount NUMERIC (comma hatao, blank = NULL), aur duplicates hata do.
CREATE TABLE bookings_clean AS
SELECT DISTINCT ON (booking_ref)
       booking_ref,
       UPPER(TRIM(agent_code)) AS agent_code,
       hotel_name,
       CASE WHEN booking_date ~ '^\d{4}-' THEN booking_date::date
            ELSE TO_DATE(booking_date, 'DD/MM/YYYY') END AS booking_date,
       NULLIF(REPLACE(amount, ',', ''), '')::numeric AS amount,
       INITCAP(TRIM(status)) AS status
FROM stg_bookings_raw
ORDER BY booking_ref, raw_id;

SELECT status, COUNT(*) FROM bookings_clean GROUP BY status;

-- Q5.5  [Foreign keys ki list (ER diagram ke liye)]
-- information_schema se saari foreign key relationships nikalo, phir dbdiagram.io par ER diagram banao.
SELECT tc.table_name  AS child_table,
       kcu.column_name AS child_column,
       ccu.table_name  AS parent_table,
       ccu.column_name AS parent_column
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu ON kcu.constraint_name = tc.constraint_name
JOIN information_schema.constraint_column_usage ccu ON ccu.constraint_name = tc.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_schema = 'public'
ORDER BY child_table, child_column;


-- ---------------------------------------------------------------
-- WEEK 6: Performance aur Reliability
-- ---------------------------------------------------------------
-- Q6.1  [Index: pehle aur baad]
-- Is query par EXPLAIN ANALYZE chalao (index se pehle), phir (agent_id, search_date) par index banao aur dobara chalao. Time compare karo.
EXPLAIN ANALYZE
SELECT * FROM searches
WHERE agent_id = 5 AND search_date BETWEEN DATE '2026-01-01' AND DATE '2026-03-31';

CREATE INDEX idx_searches_agent_date ON searches (agent_id, search_date);

EXPLAIN ANALYZE
SELECT * FROM searches
WHERE agent_id = 5 AND search_date BETWEEN DATE '2026-01-01' AND DATE '2026-03-31';

-- Q6.2  [Sargable query]
-- bookings.booking_date par index banao. Phir 2026 ki bookings ko EXTRACT(YEAR ...) se aur date range se, dono tareeke se chalakar EXPLAIN mein fark dekho.
CREATE INDEX idx_bookings_date ON bookings (booking_date);

-- Non-sargable (index use nahi hoga)
EXPLAIN ANALYZE SELECT COUNT(*) FROM bookings WHERE EXTRACT(YEAR FROM booking_date) = 2026;

-- Sargable (index use hoga)
EXPLAIN ANALYZE SELECT COUNT(*) FROM bookings
WHERE booking_date >= DATE '2026-01-01' AND booking_date < DATE '2027-01-01';

-- Q6.3  [Transaction]
-- Transaction ke andar booking 1 ko Cancelled karo, check karo, phir ROLLBACK karke wapas pehle jaisa kar do.
BEGIN;
UPDATE bookings SET status = 'Cancelled' WHERE booking_id = 1;
SELECT booking_id, status FROM bookings WHERE booking_id = 1;
ROLLBACK;
SELECT booking_id, status FROM bookings WHERE booking_id = 1;

-- Q6.4  [View]
-- v_agent_revenue naam ka view banao: agent_id, agent_name, confirmed bookings aur revenue.
CREATE VIEW v_agent_revenue AS
SELECT a.agent_id, a.agent_name,
       COUNT(b.booking_id) AS confirmed_bookings,
       COALESCE(SUM(b.amount), 0) AS revenue
FROM agents a
LEFT JOIN bookings b ON b.agent_id = a.agent_id AND b.status = 'Confirmed'
GROUP BY a.agent_id, a.agent_name;

SELECT * FROM v_agent_revenue ORDER BY revenue DESC LIMIT 10;

-- Q6.5  [Materialized view]
-- mv_monthly_revenue banao (month, revenue) aur use refresh karna seekho.
CREATE MATERIALIZED VIEW mv_monthly_revenue AS
SELECT DATE_TRUNC('month', booking_date)::date AS month, SUM(amount) AS revenue
FROM bookings WHERE status = 'Confirmed'
GROUP BY 1;

REFRESH MATERIALIZED VIEW mv_monthly_revenue;
SELECT * FROM mv_monthly_revenue ORDER BY month LIMIT 5;

-- Q6.6  [Function]
-- get_agent_revenue(p_agent_id) function banao jo us agent ka Confirmed revenue return kare.
CREATE OR REPLACE FUNCTION get_agent_revenue(p_agent_id INT)
RETURNS NUMERIC AS $$
    SELECT COALESCE(SUM(amount), 0)
    FROM bookings
    WHERE agent_id = p_agent_id AND status = 'Confirmed';
$$ LANGUAGE sql;

SELECT get_agent_revenue(1);

-- Q6.7  [Trigger]
-- bookings ka status badalne par audit_log mein entry daalne wala trigger banao. Test transaction ke andar karo.
CREATE OR REPLACE FUNCTION fn_audit_booking_status() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status IS DISTINCT FROM OLD.status THEN
        INSERT INTO audit_log (table_name, record_id, action, old_value, new_value)
        VALUES ('bookings', OLD.booking_id, 'UPDATE', OLD.status, NEW.status);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_audit_booking_status
AFTER UPDATE ON bookings
FOR EACH ROW EXECUTE FUNCTION fn_audit_booking_status();

BEGIN;
UPDATE bookings SET status = 'Pending' WHERE booking_id = 2;
SELECT * FROM audit_log;
ROLLBACK;


-- ---------------------------------------------------------------
-- WEEK 7: Data Engineering Foundation
-- ---------------------------------------------------------------
-- Q7.1  [Star schema: dim aur fact]
-- dim_agent (agent + branch + agency + country ek jagah) aur fact_bookings table banao.
CREATE TABLE dim_agent AS
SELECT a.agent_id, a.agent_code, a.agent_name,
       br.branch_name, ag.agency_name, ag.agency_type, c.country_name
FROM agents a
JOIN branches br ON br.branch_id = a.branch_id
JOIN agencies ag ON ag.agency_id = br.agency_id
JOIN countries c ON c.country_id = ag.country_id;
ALTER TABLE dim_agent ADD PRIMARY KEY (agent_id);

CREATE TABLE fact_bookings AS
SELECT booking_id, agent_id, hotel_id, booking_date, nights, amount, status
FROM bookings;
ALTER TABLE fact_bookings ADD PRIMARY KEY (booking_id);

-- Q7.2  [Query on star schema]
-- Star schema se country aur agency_type ke hisaab se Confirmed revenue nikalo. (Ab sirf 2 table join hui, pehle 5 thi.)
SELECT d.country_name, d.agency_type, SUM(f.amount) AS revenue
FROM fact_bookings f
JOIN dim_agent d ON d.agent_id = f.agent_id
WHERE f.status = 'Confirmed'
GROUP BY d.country_name, d.agency_type
ORDER BY revenue DESC
LIMIT 10;

-- Q7.3  [SCD Type 2]
-- dim_hotel_scd banao (valid_from, valid_to, is_current). Phir hotel 1 ki star rating badlo: purani row band karo, nayi row daalo.
CREATE TABLE dim_hotel_scd AS
SELECT hotel_id, hotel_name, star_rating,
       DATE '2025-01-01' AS valid_from,
       DATE '9999-12-31' AS valid_to,
       TRUE AS is_current
FROM hotels;

-- Hotel 1 ki rating badal gayi (SCD Type 2 tareeka)
UPDATE dim_hotel_scd
SET valid_to = CURRENT_DATE - 1, is_current = FALSE
WHERE hotel_id = 1 AND is_current;

INSERT INTO dim_hotel_scd
SELECT hotel_id, hotel_name, 5, CURRENT_DATE, DATE '9999-12-31', TRUE
FROM hotels WHERE hotel_id = 1;

SELECT * FROM dim_hotel_scd WHERE hotel_id = 1 ORDER BY valid_from;

-- Q7.4  [Incremental load]
-- Naye bookings (jo fact_bookings mein nahi hain) ko hi load karne ka pattern likho. (Staging -> fact)
INSERT INTO fact_bookings (booking_id, agent_id, hotel_id, booking_date, nights, amount, status)
SELECT booking_id, agent_id, hotel_id, booking_date, nights, amount, status
FROM bookings
WHERE booking_id > (SELECT COALESCE(MAX(booking_id), 0) FROM fact_bookings);

-- Q7.5  [Partitioning]
-- searches ki partitioned copy banao (search_date ke hisaab se 2025 aur 2026 partitions). EXPLAIN mein partition pruning dekho.
CREATE TABLE searches_p (
    search_id BIGINT, agent_id INT, destination_id INT,
    search_ts TIMESTAMP, search_date DATE NOT NULL,
    checkin_date DATE, nights INT, adults INT
) PARTITION BY RANGE (search_date);

CREATE TABLE searches_p_2025 PARTITION OF searches_p FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');
CREATE TABLE searches_p_2026 PARTITION OF searches_p FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');

INSERT INTO searches_p SELECT * FROM searches;

EXPLAIN SELECT COUNT(*) FROM searches_p WHERE search_date >= DATE '2026-06-01';


-- ---------------------------------------------------------------
-- WEEK 8: Capstone Project
-- ---------------------------------------------------------------
-- Q8.1  [Search-to-booking conversion]
-- Destination-wise: total searches, total bookings, Confirmed bookings aur conversion % (confirmed/searches).
SELECT d.city,
       COUNT(DISTINCT s.search_id) AS searches,
       COUNT(b.booking_id) AS bookings,
       COUNT(b.booking_id) FILTER (WHERE b.status = 'Confirmed') AS confirmed,
       ROUND(100.0 * COUNT(b.booking_id) FILTER (WHERE b.status = 'Confirmed')
             / COUNT(DISTINCT s.search_id), 2) AS conversion_pct
FROM searches s
JOIN destinations d    ON d.destination_id = s.destination_id
LEFT JOIN bookings b   ON b.search_id = s.search_id
GROUP BY d.city
ORDER BY conversion_pct DESC;

-- Q8.2  [Agent segmentation (aapka real kaam)]
-- Top-10 destinations par agents ko segment karo: searches_top10 aur confirmed_top10 ke hisaab se 'Power' (conv >= 20%), 'Browser' (searches >= 200 par conv < 10%), 'Dormant' (searches = 0) ya 'Regular'.
WITH s AS (
    SELECT s.agent_id, COUNT(*) AS searches_top10
    FROM searches s JOIN destinations d ON d.destination_id = s.destination_id
    WHERE d.is_top10
    GROUP BY s.agent_id
), b AS (
    SELECT b.agent_id, COUNT(*) AS confirmed_top10
    FROM bookings b
    JOIN hotels h ON h.hotel_id = b.hotel_id
    JOIN destinations d ON d.destination_id = h.destination_id
    WHERE d.is_top10 AND b.status = 'Confirmed'
    GROUP BY b.agent_id
), x AS (
    SELECT a.agent_id,
           COALESCE(s.searches_top10, 0) AS searches_top10,
           COALESCE(b.confirmed_top10, 0) AS confirmed_top10
    FROM agents a
    LEFT JOIN s ON s.agent_id = a.agent_id
    LEFT JOIN b ON b.agent_id = a.agent_id
)
SELECT *,
       ROUND(100.0 * confirmed_top10 / NULLIF(searches_top10, 0), 1) AS conv_pct,
       CASE WHEN searches_top10 = 0 THEN 'Dormant'
            WHEN 100.0 * confirmed_top10 / searches_top10 >= 20 THEN 'Power'
            WHEN searches_top10 >= 200 AND 100.0 * confirmed_top10 / searches_top10 < 10 THEN 'Browser'
            ELSE 'Regular' END AS segment
FROM x
ORDER BY searches_top10 DESC;

-- Q8.3  [Cancellation analysis]
-- agency_type aur country ke hisaab se cancellation rate (%) nikalo, sabse zyada cancellation wale upar.
SELECT d.country_name, d.agency_type,
       COUNT(*) AS bookings,
       ROUND(100.0 * COUNT(*) FILTER (WHERE f.status = 'Cancelled') / COUNT(*), 1) AS cancel_pct
FROM bookings f
JOIN dim_agent d ON d.agent_id = f.agent_id
GROUP BY d.country_name, d.agency_type
ORDER BY cancel_pct DESC
LIMIT 10;

-- Q8.4  [Trend + moving average]
-- Month-wise Confirmed revenue aur uska 3-month moving average.
WITH m AS (
    SELECT DATE_TRUNC('month', booking_date)::date AS month, SUM(amount) AS revenue
    FROM bookings WHERE status = 'Confirmed' GROUP BY 1
)
SELECT month, revenue,
       ROUND(AVG(revenue) OVER (ORDER BY month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW), 2) AS moving_avg_3m
FROM m ORDER BY month;

-- Q8.5  [Data quality check]
-- Confirmed bookings jinke payments ka total booking amount se match nahi karta (0 aana chahiye), aur payment ke bina Confirmed bookings.
SELECT COUNT(*) AS payment_mismatch
FROM (SELECT b.booking_id
      FROM bookings b JOIN payments p ON p.booking_id = b.booking_id
      WHERE b.status = 'Confirmed'
      GROUP BY b.booking_id, b.amount
      HAVING ABS(SUM(p.amount) - b.amount) > 0.05) t;

SELECT COUNT(*) AS confirmed_without_payment
FROM bookings b
WHERE b.status = 'Confirmed'
  AND NOT EXISTS (SELECT 1 FROM payments p WHERE p.booking_id = b.booking_id);

